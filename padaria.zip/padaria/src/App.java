package main;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("BEM VINDO A PADARIA DO SEU CHICO, VAMOS COMEÇAR \r\n");
        System.out.println("VOCÊ DESEJA CARREGAR ALGUNS PRODUTOS EM MEMÓRIA POR PADRÃO?");
    }
}
