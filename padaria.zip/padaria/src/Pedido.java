public class Pedido {
    private Array<Produto> produtos;
    
    public void AdicionarProduto(Produto produto) {
        produtos.push(produto)
    }

    public Array<Produto> RetornarTodosOsProdutos() {
        return this.produtos;
    }

    public String toString() {
        return this.produtos.toString();
    }
}